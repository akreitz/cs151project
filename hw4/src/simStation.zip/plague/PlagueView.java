package plague;

import mvc.*;
import simStation.*;

/*
 * Edit History 
 * 4/1  - Created
 * 
 */

public class PlagueView extends SimulationView {

	public PlagueView(Model model) {
		super(model);
	}

}
