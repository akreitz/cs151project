package simStation;

import mvc.*;
import java.awt.*;

public class SimulationView extends View{

	public SimulationView(Simulation sim) {
		super(sim);
	}
	
	public void paintComponent(Graphics gc) {
		
		Simulation sim = (Simulation) model;
		Color oldColor = gc.getColor();
		
		gc.setColor(Color.BLACK);
		gc.drawRect(0, 0, Simulation.WORLD_SIZE, Simulation.WORLD_SIZE);
		
		gc.setColor(Color.RED);
		
		
		for (Agent a : sim.getAgents()) {
			if (a != null) {
				gc.fillOval(a.getLocation().x, a.getLocation().y, Simulation.SIZE, Simulation.SIZE);
			} else {
				break;
			}
		}
		/*
		for (int i = 0; i < sim.getAgents().length; i++) {
			Agent current;
			if ((current = sim.getAgents()[i]) != null) {
				gc.fillOval(current.getLocation().x, current.getLocation().y, Simulation.SIZE, Simulation.SIZE);
			} else {
				break;
			}
		}
		*/
		
		
		gc.setColor(oldColor);
	}
}
