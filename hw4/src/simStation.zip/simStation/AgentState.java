package simStation;

public enum AgentState {
	READY, RUNNING, SUSPENDED, STOPPED;
}
