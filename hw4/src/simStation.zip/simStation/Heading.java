package simStation;

import mvc.*;

public enum Heading {
	NORTH, EAST, SOUTH, WEST;
	
	public static Heading randHeading() {
		
		switch(Utilities.rng.nextInt(4)) {
		case 0:
			return NORTH;
		case 1:
			return EAST;
		case 2:
			return SOUTH;
		case 3:
			return WEST;
		}
		
		return null;
	}
}
