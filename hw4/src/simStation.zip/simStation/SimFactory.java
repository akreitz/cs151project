package simStation;

import mvc.*;

/*
 * Edit History 
 * 4/8  - Created
 * 
 */ 

public interface SimFactory extends AppFactory {
	
	public View getView(Model m);
}
