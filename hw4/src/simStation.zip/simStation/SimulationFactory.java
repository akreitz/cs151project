package simStation;

import mvc.*;

public class SimulationFactory implements SimFactory {

	@Override
	public Model makeModel() { return new Simulation(); }

	@Override
	public View getView(Model m) {
		return new SimulationView((Simulation) m);
	}

	@Override
	public String[] getEditCommands() {
		return new String[] { "Start", "Suspend", "Resume", "Stop", "Stats" };
	}

	@Override
	public Command makeEditCommand(Model model, String type) {
		switch(type) {
			case "Start":
				return new StartCommand(model);
			case "Suspend":
				return new SuspendCommand(model);
			case "Resume":
				return new ResumeCommand(model);
			case "Stop":
				return new StopCommand(model);
			case "Stats":
				return new StatsCommand(model);
		}
		return null;
	}

	@Override
	public String getTitle() {
		return "SimStation";
	}

	@Override
	public String[] getHelp() {
		return new String[] { 
							  "Start: changes the heading of the turtle (N, S, E, W)\n",
							  "Suspend: moves the turtle a specified number of steps in the current direction\n",
							  "Resume: clears the canvas\n",
							  "Stop: changes whether the pen is down (drawing) or up (not drawing)\n",
							  "Stats: changes the color of the pen" 
							 };
	}

	@Override
	public String about() {
		return "SimStation, CS 151 SP20 Project, Alex Kreitz";
	}

}
