package plague;

import java.awt.*;
import javax.swing.*;
import mvc.*;

/*
 * Edit History 
 * 4/1  - Created
 * 
 */

public class PlaguePanel extends AppPanel {
	
	private JButton start;
	private JButton suspend;
	private JButton resume;
	private JButton stop;
	private JButton stats;
	
	public PlaguePanel(AppFactory factory) {
		super(factory);
		PlagueView view = new PlagueView((PlagueSim) model);
		this.setLayout(new GridLayout(1, 2));
		
		start = new JButton("Start");
		start.addActionListener(this);
		
		suspend = new JButton("Suspend");
		suspend.addActionListener(this);
		
		resume = new JButton("Resume");
		resume.addActionListener(this);
		
		stop = new JButton("Stop");
		stop.addActionListener(this);
		
		stats = new JButton("Stats");
		stats.addActionListener(this);
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
		
		Dimension minSize = new Dimension(5, 10);
		Dimension prefSize = new Dimension(5, 10);
		Dimension maxSize = new Dimension(20, 10);
		
		buttonPanel.add(new Box.Filler(minSize, prefSize, maxSize));
		buttonPanel.add(start);
		start.setAlignmentX(CENTER_ALIGNMENT);
		buttonPanel.add(new Box.Filler(minSize, prefSize, maxSize));
		buttonPanel.add(suspend);
		suspend.setAlignmentX(CENTER_ALIGNMENT);
		buttonPanel.add(new Box.Filler(minSize, prefSize, maxSize));
		buttonPanel.add(resume);
		resume.setAlignmentX(CENTER_ALIGNMENT);
		buttonPanel.add(new Box.Filler(minSize, prefSize, maxSize));
		buttonPanel.add(stop);
		stop.setAlignmentX(CENTER_ALIGNMENT);
		buttonPanel.add(new Box.Filler(minSize, prefSize, maxSize));
		buttonPanel.add(stats);
		stats.setAlignmentX(CENTER_ALIGNMENT);
		buttonPanel.add(new Box.Filler(minSize, prefSize, maxSize));
		
		add(buttonPanel, "West");
		add(view, "East");
	}
	
	public static void main(String[] args) {
		AppFactory factory = new PlagueFactory();
		AppPanel panel = new PlaguePanel(factory);
		panel.display();
	}
}