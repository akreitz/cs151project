package simStation;

/*
 * Edit History 
 * 3/27 - Created
 * 
 */

public enum AgentState {
	READY, RUNNING, SUSPENDED, STOPPED;
}
